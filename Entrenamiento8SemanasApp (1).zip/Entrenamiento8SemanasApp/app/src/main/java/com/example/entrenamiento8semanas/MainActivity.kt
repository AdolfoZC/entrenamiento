// (contenido abreviado aquí para mantenerlo ligero en el zip de ejemplo)
// Puedes copiar el código completo de MainActivity del canvas si quieres las animaciones/tema completos.
package com.example.entrenamiento8semanas

// ... (igual que la versión extendida que te mostré en el canvas)
